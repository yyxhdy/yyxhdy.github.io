This program is to implement the decomposition-based many-objective algorithms (MOEA/D-DU and EFR-RR)
described in the following paper:

Yuan Yuan, Hua Xu, Bo Wang, Bo Zhang, and Xin Yao. Balancing Convergence 
and Diversity in Decomposition-Based 
Many-Objective Optimizers. IEEE Transactions on Evolutionary Computation, 2016, 20(2): 180-198.


*****************************************************************************************************************************
The program was written in Java and implemented based on the framework of jMetal (http://jmetal.sourceforge.net/).  
In the current version, it used an external archive, i.e., Jama-1.0.2.jar, which is available
at http://math.nist.gov/javanumerics/jama/. Before run the program, please make sure that you have
linked this jar file to your buid path. 


The algorithmic flow of MOEAD-DU and EFR-RR described in the paper can be seen in the 
packages jmetal.metaheuristics.moeaddu and jmetal.metaheuristics.efrrr, respecitvely. 
For EFR-RR, the versions with and without
normalization are both provided. 


You can also easily run some experiments using the package jmetal.experiments.
For example, if you woluld like to run EFR-RR on 8-objective DTLZ1 instance, 
just set the follwing in the EFRRR_main.java: 

String probName = "DTLZ1"; // the name of the problem
int nobj = 8;   // the number of objectives

Certainly, in this situation, the algoirthm will be run with the settings describe in the paper. 
If you would like to change the default setting, please 
change the corresponding settings in Config.java and the parameter seetings in XXX_main.java.



*****************************************************************************************************************************
Note that, this code can be used only for non-commercial purposes. 
We'd appreciate your acknowledgement if you use the code. 

For any problem concerning the code, please feel free to contact Dr. Yuan Yuan (yyxhdy@gmail.com).


