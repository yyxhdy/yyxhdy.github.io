package jmetal.metaheuristics.efrrr;


import Jama.Matrix;
import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.util.JMException;


import jmetal.util.NonDominatedSolutionList;
import jmetal.util.Permutation;
import jmetal.util.PseudoRandom;
import jmetal.util.ranking.NondominatedRanking;
import jmetal.util.ranking.NormEnsembleFitnessRanking;
import jmetal.util.ranking.Ranking;
import jmetal.util.vector.TwoLevelWeightVectorGenerator;
import jmetal.util.vector.VectorGenerator;


// This is the implementation of EFR-RR with normalization


public class EFRRRNORM extends Algorithm {

	private int populationSize_;

	private SolutionSet population_;

	SolutionSet offspringPopulation_;

	SolutionSet union_;

	private int evaluations_;

	Operator crossover_;
	Operator mutation_;
	Operator selection_;


	int div1_;
	int div2_;

	double[] zideal_;
	
	double[] znadir_;

	double[][] lambda_;
	
	
	int K_;
	
	
	int generations_;
	
	
	double[][] extremePoints_; // extreme points


	public EFRRRNORM(Problem problem) {
		super(problem);
	}

	public SolutionSet execute() throws JMException, ClassNotFoundException {

		int maxEvaluations;
		
		generations_ = 0;

		evaluations_ = 0;
		maxEvaluations = ((Integer) this.getInputParameter("maxEvaluations"))
				.intValue();



		div1_ = ((Integer) this.getInputParameter("div1")).intValue();
		div2_ = ((Integer) this.getInputParameter("div2")).intValue();
		
		K_ = ((Integer) this.getInputParameter("K")).intValue();

		VectorGenerator vg = new TwoLevelWeightVectorGenerator(div1_, div2_,
				problem_.getNumberOfObjectives());
		lambda_ = vg.getVectors();
		
		zideal_ = new double[problem_.getNumberOfObjectives()];

		populationSize_ = vg.getVectors().length;

		population_ = new SolutionSet(populationSize_);


		mutation_ = operators_.get("mutation");
		crossover_ = operators_.get("crossover");

		
		initPopulation();
		
		initIdealPoint();
		
		initNadirPoint();    // initialize the nadir point
		
		initExtremePoints(); // initialize the extreme points
		
		
		while (evaluations_ < maxEvaluations) {

			// Create the offSpring solutionSet
			offspringPopulation_ = new SolutionSet(populationSize_);
			
			for (int i = 0; i < populationSize_; i++) {
				if (evaluations_ < maxEvaluations) {
					doGeneticOperator(i);
				} // if
			} // for

			union_ = ((SolutionSet) population_).union(offspringPopulation_);
			
			
			SolutionSet nondominatedSet = getNondominatedSolutions();
			
			updateNadirPoint(nondominatedSet);  // update the nadir point
			normalizePopulation(union_); 
			
			Ranking ranking = new NormEnsembleFitnessRanking(union_, lambda_, K_);
			
			int remain = populationSize_;
			int index = 0;
			SolutionSet front = null;
			population_.clear();

			front = ranking.getSubfront(index);

			while ((remain > 0) && (remain >= front.size())) {

				for (int k = 0; k < front.size(); k++) {
					population_.add(front.get(k));
				} // for

				// Decrement remain
				remain = remain - front.size();

				// Obtain the next front
				index++;
				if (remain > 0) {
					front = ranking.getSubfront(index);
				} // if
			} // while

			if (remain > 0) { // front contains individuals to insert
				int[] perm = new Permutation().intPermutation(front.size());
				for (int k = 0; k < remain; k++) {
					population_.add(front.get(perm[k]));
				} // for
				remain = 0;
			} // if
		
		}
		
		NondominatedRanking ranking = new NondominatedRanking(population_);
		return ranking.getSubfront(0);
	}

	
	void doGeneticOperator(int i) throws JMException{
		int r;
		do {
			r = PseudoRandom.randInt(0, populationSize_ - 1);
		} while (r == i);
		
		Solution[] parents = new Solution[2];
		
		parents[0] = population_.get(i);
		parents[1] = population_.get(r);
		
		Solution[] offSpring = (Solution[]) crossover_
				.execute(parents);
		
		
		mutation_.execute(offSpring[0]);
		
		problem_.evaluate(offSpring[0]);
		
		
		 
		updateIdealPoint(offSpring[0]);
		
		evaluations_++;
		
		offspringPopulation_.add(offSpring[0]);
	}
	
	
	
	public void initIdealPoint() {
		zideal_ = new double[problem_.getNumberOfObjectives()];
		for (int i = 0; i < zideal_.length; i++)
			zideal_[i] = 1.0e+30;
		
		for (int i = 0; i < populationSize_; i++) {
			updateIdealPoint(population_.get(i));
		} // for
	}

	public void initPopulation() throws JMException, ClassNotFoundException {

		population_ = new SolutionSet(populationSize_);
		for (int i = 0; i < populationSize_; i++) {
			Solution newSolution = new Solution(problem_);

			problem_.evaluate(newSolution);

			updateIdealPoint(newSolution);

			evaluations_++;
			population_.add(newSolution);
		} // for
	} // initPopulation

	public void updateIdealPoint(Solution individual) {
		for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
			double val = individual.getObjective(j);
			if (val < zideal_[j])
				zideal_[j] = val;
		}
	}
	
	
	
	SolutionSet getNondominatedSolutions(){
		SolutionSet set = new NonDominatedSolutionList();
		for (int i = 0; i < union_.size(); i++)
			set.add(union_.get(i));
		
		return set;
	}
	
	
	
	void copyObjectiveValues(double[] array, Solution individual) {
		for (int i = 0; i < individual.numberOfObjectives(); i++) {
			array[i] = individual.getObjective(i);
		}
	}
	

	double asfFunction(Solution sol, int j) {
		double max = Double.MIN_VALUE;
		double epsilon = 1.0E-6;

		int obj = problem_.getNumberOfObjectives();

		for (int i = 0; i < obj; i++) {

			double val = Math.abs((sol.getObjective(i) - zideal_[i])
					/ (znadir_[i] - zideal_[i]));

			if (j != i)
				val = val / epsilon;

			if (val > max)
				max = val;
		}

		return max;
	}

	double asfFunction(double[] ref, int j) {
		double max = Double.MIN_VALUE;
		double epsilon = 1.0E-6;

		int obj = problem_.getNumberOfObjectives();

		for (int i = 0; i < obj; i++) {

			double val = Math.abs((ref[i] - zideal_[i])
					/ (znadir_[i] - zideal_[i]));
			

			if (j != i)
				val = val / epsilon;

			if (val > max)
				max = val;
		}

		return max;
	}
	
	
	void initNadirPoint() {
		int obj = problem_.getNumberOfObjectives();
		znadir_ = new double[obj];
		for (int j = 0; j < obj; j++) {
			znadir_[j] = Double.MIN_VALUE;

			for (int i = 0; i < population_.size(); i++) {
				if (population_.get(i).getObjective(j) > znadir_[j])
					znadir_[j] = population_.get(i).getObjective(j);
			}
		}
	}
	
	
	void updateNadirPoint(SolutionSet pop){
		
		updateExtremePoints(pop);

		
		int obj = problem_.getNumberOfObjectives();
		double[][] temp = new double[obj][obj];

		for (int i = 0; i < obj; i++) {
			for (int j = 0; j < obj; j++) {
				double val = extremePoints_[i][j] - zideal_[j];
				temp[i][j] = val;
			}
		}

		Matrix EX = new Matrix(temp);

		boolean sucess = true;
		
		if (EX.rank() == EX.getRowDimension()) {
			double[] u = new double[obj];
			for (int j = 0; j < obj; j++)
				u[j] = 1;

			Matrix UM = new Matrix(u, obj);

			Matrix AL = EX.inverse().times(UM);

			int j = 0;
			for (j = 0; j < obj; j++) {

				double aj = 1.0 / AL.get(j, 0) + zideal_[j];
		

				if ((aj > zideal_[j]) && (!Double.isInfinite(aj)) && (!Double.isNaN(aj)))
					znadir_[j] = aj;
				else {
					sucess = false;
					break;
				}
			}
		} 
		else 
			sucess = false;
		
		
		if (!sucess){
			double[] zmax = computeMaxPoint(pop);
			for (int j = 0; j < obj; j++) {
				znadir_[j] = zmax[j];
			}
		}
	}
	
	
	
	
	public void updateExtremePoints(SolutionSet pop){
		for (int i = 0; i < pop.size(); i++)
			updateExtremePoints(pop.get(i));
	}
	
	
	public void updateExtremePoints(Solution individual){
		int obj = problem_.getNumberOfObjectives();
		for (int i = 0; i < obj; i++){
			double asf1 = asfFunction(individual, i);
			double asf2 = asfFunction(extremePoints_[i], i);
			
			if (asf1 < asf2){
				copyObjectiveValues(extremePoints_[i], individual);
			}
		}
	}
	
	
	double[] computeMaxPoint(SolutionSet pop){
		int obj = problem_.getNumberOfObjectives();
		double zmax[] = new double[obj];
		for (int j = 0; j < obj; j++) {
			zmax[j] = Double.MIN_VALUE;

			for (int i = 0; i < pop.size(); i++) {
				if (pop.get(i).getObjective(j) > zmax[j])
					zmax[j] = pop.get(i).getObjective(j);
			}
		}
		return zmax;
	}
	
	void normalizePopulation(SolutionSet pop) {

		int obj = problem_.getNumberOfObjectives();

		for (int i = 0; i < pop.size(); i++) {
			Solution sol = pop.get(i);

			for (int j = 0; j < obj; j++) {

				double val = (sol.getObjective(j) - zideal_[j])
						/ (znadir_[j] - zideal_[j]);

				sol.setNormalizedObjective(j, val);
			}
		}
	}
	
	
	
	void initExtremePoints() {
		int obj = problem_.getNumberOfObjectives();
		extremePoints_ = new double[obj][obj];
		for (int i = 0; i < obj; i++){
			for (int j = 0; j < obj; j++){
				extremePoints_[i][j] = 1.0e+30;
			}
		}
		
	}
	
}
