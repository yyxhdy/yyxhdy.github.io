package jmetal.metaheuristics.efrrr;


import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;

import jmetal.util.JMException;


import jmetal.util.Permutation;
import jmetal.util.PseudoRandom;
import jmetal.util.ranking.EnsembleFitnessRanking;
import jmetal.util.ranking.NondominatedRanking;
import jmetal.util.ranking.Ranking;

import jmetal.util.vector.TwoLevelWeightVectorGenerator;
import jmetal.util.vector.VectorGenerator;


// This is the implementation of EFR-RR without normalization


public class EFRRR extends Algorithm {

	private int populationSize_;    // population size

	private SolutionSet population_;  // current population

	SolutionSet offspringPopulation_;  // offspring population

	SolutionSet union_;   // combined population

	private int evaluations_;  // the number of function evaluations

	Operator crossover_;   // crossover operator
	Operator mutation_;    // mutation operator


	int div1_;    // divisions of boundary layer
	int div2_;    // divisions of inner layer

	double[] zideal_;   // ideal point

	double[][] lambda_;  // well-distributed weight vectors
	
	
	int K_;   // parameter K
	


	public EFRRR(Problem problem) {
		super(problem);
	}

	public SolutionSet execute() throws JMException, ClassNotFoundException {

		int maxEvaluations;

		evaluations_ = 0;
		
		maxEvaluations = ((Integer) this.getInputParameter("maxEvaluations"))
				.intValue();   // set the maximum number of function evaluations



		div1_ = ((Integer) this.getInputParameter("div1")).intValue();  // set div1
		div2_ = ((Integer) this.getInputParameter("div2")).intValue();  // set div2
		
		K_ = ((Integer) this.getInputParameter("K")).intValue();  // set the parameter K

		
		//Generate the diverse weight vectors
		VectorGenerator vg = new TwoLevelWeightVectorGenerator(div1_, div2_,
				problem_.getNumberOfObjectives());
		lambda_ = vg.getVectors();
		
		
		zideal_ = new double[problem_.getNumberOfObjectives()];

		populationSize_ = vg.getVectors().length;

		population_ = new SolutionSet(populationSize_);


		crossover_ = operators_.get("crossover"); // SBX crossover
		mutation_ = operators_.get("mutation");   // polynomial mutation
		
		
		initPopulation();  // initialize the population
		
		initIdealPoint();  // initialize the ideal point

		while (evaluations_ < maxEvaluations) {

			// Create the offSpring solutionSet
			offspringPopulation_ = new SolutionSet(populationSize_);
			
			
			// execute genetic operators to produce the offspring population
			for (int i = 0; i < populationSize_; i++) {
				if (evaluations_ < maxEvaluations) {
					doGeneticOperator(i);
				} // if
			} // for

			
			// combine the current population with the offspring population
			union_ = ((SolutionSet) population_).union(offspringPopulation_);
			
			
			// execute ensemble fitness ranking
			Ranking ranking = new EnsembleFitnessRanking(union_, lambda_, zideal_, K_);
			
			
			/*
			 *  select half number of solutions to form the next population, just randomly choose the 
			 *  solutions in the last accepted front
			 * 
			 */
			
			
			int remain = populationSize_;
			int index = 0;
			SolutionSet front = null;
			population_.clear();

			front = ranking.getSubfront(index);

			while ((remain > 0) && (remain >= front.size())) {

				for (int k = 0; k < front.size(); k++) {
					population_.add(front.get(k));
				} // for

				// Decrement remain
				remain = remain - front.size();

				// Obtain the next front
				index++;
				if (remain > 0) {
					front = ranking.getSubfront(index);
				} // if
			} // while

			if (remain > 0) { // front contains individuals to insert
				int[] perm = new Permutation().intPermutation(front.size());
				for (int k = 0; k < remain; k++) {
					population_.add(front.get(perm[k]));
				} // for
				remain = 0;
			} // if
		}
		
		
		NondominatedRanking ranking = new NondominatedRanking(population_);
		return ranking.getSubfront(0);

	}

	
	void doGeneticOperator(int i) throws JMException{
		int r;
		do {
			r = PseudoRandom.randInt(0, populationSize_ - 1);
		} while (r == i);
		
		Solution[] parents = new Solution[2];
		
		parents[0] = population_.get(i);
		parents[1] = population_.get(r);
		
		Solution[] offSpring = (Solution[]) crossover_
				.execute(parents);
		
		
		mutation_.execute(offSpring[0]);
		
		problem_.evaluate(offSpring[0]);
		
		
		 
		updateIdealPoint(offSpring[0]);
		
		evaluations_++;
		
		offspringPopulation_.add(offSpring[0]);
	}
	
	
	public void initIdealPoint() {
		zideal_ = new double[problem_.getNumberOfObjectives()];
		for (int i = 0; i < zideal_.length; i++)
			zideal_[i] = 1.0e+30;
		
		for (int i = 0; i < populationSize_; i++) {
			updateIdealPoint(population_.get(i));
		} // for
	}

	public void initPopulation() throws JMException, ClassNotFoundException {

		population_ = new SolutionSet(populationSize_);
		for (int i = 0; i < populationSize_; i++) {
			Solution newSolution = new Solution(problem_);

			problem_.evaluate(newSolution);

			updateIdealPoint(newSolution);

			evaluations_++;
			population_.add(newSolution);
		} // for
	} // initPopulation

	public void updateIdealPoint(Solution individual) {
		for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
			double val = individual.getObjective(j);
			if (val < zideal_[j])
				zideal_[j] = val;
		}
	}

}
