package jmetal.problems.DTLZ;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.experiments.Config;
import jmetal.util.JMException;

/**
 * Class representing problem NDTLZ7
 */
public class NDTLZ7 extends Problem {

	/**
	 * Creates a default DTLZ7 problem instance (22 variables and 3 objectives)
	 * 
	 * @param solutionType
	 *            The solution type must "Real" or "BinaryReal".
	 */
	public NDTLZ7(String solutionType) throws ClassNotFoundException {
		this(solutionType, 22, 3);
	} // DTLZ7

	/**
	 * Creates a new DTLZ7 problem instance
	 * 
	 * @param numberOfVariables
	 *            Number of variables
	 * @param numberOfObjectives
	 *            Number of objective functions
	 * @param solutionType
	 *            The solution type must "Real" or "BinaryReal".
	 */
	public NDTLZ7(String solutionType, Integer numberOfVariables,
			Integer numberOfObjectives) {
		numberOfVariables_ = numberOfVariables;
		numberOfObjectives_ = numberOfObjectives;
		numberOfConstraints_ = 0;
		problemName_ = "NDTLZ7";

		lowerLimit_ = new double[numberOfVariables_];
		upperLimit_ = new double[numberOfVariables_];
		for (int var = 0; var < numberOfVariables_; var++) {
			lowerLimit_[var] = 0.0;
			upperLimit_[var] = 1.0;
		}

		if (solutionType.compareTo("BinaryReal") == 0)
			solutionType_ = new BinaryRealSolutionType(this);
		else if (solutionType.compareTo("Real") == 0)
			solutionType_ = new RealSolutionType(this);
		else {
			System.out.println("Error: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}
	}

	/**
	 * Evaluates a solution
	 * 
	 * @param solution
	 *            The solution to evaluate
	 * @throws JMException
	 */
	public void evaluate(Solution solution) throws JMException {
		Variable[] gen = solution.getDecisionVariables();

		double[] x = new double[numberOfVariables_];
		double[] f = new double[numberOfObjectives_];
		int k = numberOfVariables_ - numberOfObjectives_ + 1;

		for (int i = 0; i < numberOfVariables_; i++)
			x[i] = gen[i].getValue();

		// Calculate g
		double g = 0.0;
		for (int i = this.numberOfVariables_ - k; i < numberOfVariables_; i++)
			g += x[i];

		g = 1 + (9.0 * g) / k;
		// <-

		// Calculate the value of f1,f2,f3,...,fM-1 (take acount of vectors
		// start at 0)
		System.arraycopy(x, 0, f, 0, numberOfObjectives_ - 1);
		// <-

		// ->Calculate fM
		double h = 0.0;
		for (int i = 0; i < numberOfObjectives_ - 1; i++)
			h += (f[i] / (1.0 + g)) * (1 + Math.sin(3.0 * Math.PI * f[i]));

		h = numberOfObjectives_ - h;

		f[numberOfObjectives_ - 1] = (1 + g) * h;
		// <-

		// -> Setting up the value of the objetives
		
		double[] nd = getNadirForDTLZ7(numberOfObjectives_);
		
		
		for (int i = 0; i < numberOfObjectives_ - 1; i++)
			solution.setObjective(i, f[i] / nd[0]);

		solution.setObjective(numberOfObjectives_ - 1,
				(f[numberOfObjectives_ - 1] - nd[1]) / (2 * numberOfObjectives_ - nd[1]));
		// <-
	} // evaluate
	
	
	
    private double[] getNadirForDTLZ7(int obj) {
		double[] nd = new double[2];
		double min = 2.5 * Math.PI;
		double max = 3 * Math.PI;
		double mid = (min + max) / 2;

		double epsilon = 1e-9;

		double fv = func(mid);

		while (Math.abs(fv) > epsilon) {
			if (fv > 0)
				min = mid;
			else if (fv < 0)
				max = mid;

			mid = (min + max) / 2;
			fv = func(mid);
		}

		nd[0] = mid / (3 * Math.PI);

		double sum = 0;

		for (int j = 0; j < obj - 1; j++) {
			sum += mid * (1 + Math.sin(mid));
		}

		nd[1] = 2 * obj - sum / (Math.PI * 3);

		return nd;

	}

	private double func(double x) {
		return 1 + Math.sin(x) + x * Math.cos(x);
	}
}
