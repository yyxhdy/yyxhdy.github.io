package jmetal.experiments;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.experiments.Config;
import jmetal.qualityIndicator.fastHypervolume.FastHypervolume;
import jmetal.qualityIndicator.hypeHypervolume.HypEHypervolume;
import jmetal.util.comparators.DominanceComparator;

public class HV {

	public static double getHyperVolume(String probName, int objs,
			SolutionSet pop) {
		double[] nadir = Config.getNadirPoint(probName, objs);

		for (int i = 0; i < pop.size(); i++) {
			Solution sol = pop.get(i);

			for (int j = 0; j < objs; j++) {
				double val = sol.getObjective(j) / nadir[j];
				sol.setObjective(j, val);
			}
		}

		FastHypervolume fh = new FastHypervolume();
		HypEHypervolume hh = new HypEHypervolume();
		int nrOfSamples = 10000000;

		Solution ref = new Solution(objs);
		for (int j = 0; j < objs; j++) {
			ref.setObjective(j, 1.1);
		}
		Config.filterSolutions(pop, ref);

		double hv = 0;
		if (objs <= 10)
			hv = fh.computeHypervolume(pop, ref);
		else
			hv = hh.estimateHypervolume(pop, ref, nrOfSamples);

		return hv;
	}

	public static double getHyperVolume(String probName, int objs, String path)
			throws IOException {
		double[] nadir = Config.getNadirPoint(probName, objs);
		SolutionSet pop = new SolutionSet();

		FastHypervolume fh = new FastHypervolume();
		HypEHypervolume hh = new HypEHypervolume();
		int nrOfSamples = 10000000;

		FileInputStream fis = new FileInputStream(path);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		String aux = br.readLine();
		while (aux != null) {
			if (!aux.startsWith("Time")) {
				String[] st = aux.split(" ");
				Solution sol = new Solution(objs);

				for (int j = 0; j < objs; j++) {
					double val = Double.parseDouble(st[j].trim());
					sol.setObjective(j, val);
				}
				pop.add(sol);
			}
			aux = br.readLine();
		}

		br.close();

		for (int i = 0; i < pop.size(); i++) {
			Solution sol = pop.get(i);

			for (int j = 0; j < objs; j++) {
				double val = sol.getObjective(j) / nadir[j];
				sol.setObjective(j, val);
			}
		}

		Solution ref = new Solution(objs);
		for (int j = 0; j < objs; j++) {
			ref.setObjective(j, 1.1);
		}
		Config.filterSolutions(pop, ref);

		double hv = 0;
		if (objs <= 10)
			hv = fh.computeHypervolume(pop, ref);
		else
			hv = hh.estimateHypervolume(pop, ref, nrOfSamples);

		return hv;
	}

}
