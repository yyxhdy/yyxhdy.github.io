package jmetal.experiments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.metaheuristics.moeaddu.MOEADDU;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;
import jmetal.util.JMException;
import jmetal.util.vector.TwoLevelWeightVectorGenerator;
import jmetal.util.vector.VectorGenerator;

public class MOEADDU_main {
	public static void main(String args[]) throws ClassNotFoundException,
			JMException {
		Problem problem; // the problem to solve
		Algorithm algorithm; // the algorithm to use
		Operator crossover; // crossover operator
		Operator mutation; // mutation operator

		HashMap parameters; // operator parameters

		String probName = "DTLZ2";  // problem name: DTLZ1-4, NDTLZ7, NWFG1-9
		int nobj = 5;               // number of objectives: 2, 5, 8, 10, 13

		problem = Config.setProblem(probName, nobj);

		algorithm = new MOEADDU(problem);

		int[] divs = Config.setDivs(nobj);
		algorithm.setInputParameter("div1", divs[0]);
		algorithm.setInputParameter("div2", divs[1]);

		algorithm.setInputParameter("maxEvaluations", 20000 * nobj);

		algorithm.setInputParameter("T", 20);
		algorithm.setInputParameter("K", 5);
		algorithm.setInputParameter("delta", 0.9);

		parameters = new HashMap();
		parameters.put("probability", 1.0);
		parameters.put("distributionIndex", 20.0);
		crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover",
				parameters);

		// Mutation operator
		parameters = new HashMap();
		parameters.put("probability", 1.0 / problem.getNumberOfVariables());
		parameters.put("distributionIndex", 20.0);
		mutation = MutationFactory.getMutationOperator("PolynomialMutation",
				parameters);

		algorithm.addOperator("crossover", crossover);
		algorithm.addOperator("mutation", mutation);

		SolutionSet population = algorithm.execute();

		double hv = HV.getHyperVolume(probName, nobj, population);

		System.out.println(hv);

	}

}
