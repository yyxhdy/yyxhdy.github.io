package jmetal.experiments;

import java.util.HashMap;


import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.metaheuristics.efrrr.EFRRR;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;
import jmetal.util.JMException;

public class EFRRR_main {
	public static void main(String args[]) throws ClassNotFoundException,
			JMException {
		Problem problem; // the problem to solve
		Algorithm algorithm; // the algorithm to use
		Operator crossover; // crossover operator
		Operator mutation; // mutation operator

		HashMap parameters; // operator parameters

		String probName = "DTLZ2"; // problem name: DTLZ1-4, NDTLZ7, NWFG4-9
		int nobj = 5; // number of objectives: 2, 5, 8, 10, 13

		problem = Config.setProblem(probName, nobj);

		algorithm = new EFRRR(problem);

		int[] divs = Config.setDivs(nobj);
		algorithm.setInputParameter("div1", divs[0]);
		algorithm.setInputParameter("div2", divs[1]);

		algorithm.setInputParameter("maxEvaluations", 20000 * nobj);

		algorithm.setInputParameter("K", 2);

		parameters = new HashMap();
		parameters.put("probability", 1.0);
		parameters.put("distributionIndex", 30.0);
		crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover",
				parameters);

		// Mutation operator
		parameters = new HashMap();
		parameters.put("probability", 1.0 / problem.getNumberOfVariables());
		parameters.put("distributionIndex", 20.0);
		mutation = MutationFactory.getMutationOperator("PolynomialMutation",
				parameters);

		algorithm.addOperator("crossover", crossover);
		algorithm.addOperator("mutation", mutation);

		SolutionSet population = algorithm.execute();

		double hv = HV.getHyperVolume(probName, nobj, population);
		System.out.println(hv);

	}
}
