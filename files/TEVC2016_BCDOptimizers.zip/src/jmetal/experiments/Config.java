package jmetal.experiments;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.problems.ProblemFactory;

import jmetal.util.JMException;
import jmetal.util.comparators.DominanceComparator;

public class Config {

	public static double[] getNadirPoint(String name, int obj) {
		double nadir[] = new double[obj];
		if (name.equals("DTLZ1")) {
			for (int j = 0; j < obj; j++)
				nadir[j] = 0.5;
		} else if (name.equals("DTLZ2") || name.equals("DTLZ3")
				|| name.equals("DTLZ4")) {
			for (int j = 0; j < obj; j++)
				nadir[j] = 1.0;
		} else if (name.equals("SDTLZ1")) {
			if (obj == 2 || obj == 5) {
				for (int j = 0; j < obj; j++)
					nadir[j] = 0.5 * Math.pow(10, j);
			} else if (obj == 8) {
				for (int j = 0; j < obj; j++)
					nadir[j] = 0.5 * Math.pow(3, j);
			} else if (obj == 10) {
				for (int j = 0; j < obj; j++)
					nadir[j] = 0.5 * Math.pow(2, j);
			} else if (obj == 13) {
				for (int j = 0; j < obj; j++)
					nadir[j] = 0.5 * Math.pow(1.2, j);
			}

		} else if (name.equals("SDTLZ2")) {
			if (obj == 2 || obj == 5) {
				for (int j = 0; j < obj; j++)
					nadir[j] = Math.pow(10, j);
			} else if (obj == 8 || obj == 10) {
				for (int j = 0; j < obj; j++)
					nadir[j] = Math.pow(3, j);
			} else if (obj == 13) {
				for (int j = 0; j < obj; j++)
					nadir[j] = Math.pow(2, j);
			}
		} else if (name.startsWith("WFG")) {
			for (int j = 0; j < obj; j++)
				nadir[j] = 2 * (j + 1);
		} else if (name.startsWith("NWFG")) {
			for (int j = 0; j < obj; j++)
				nadir[j] = 1.0;
		} else if (name.equals("NDTLZ7")) {
			for (int j = 0; j < obj; j++)
				nadir[j] = 1.0;
		}

		return nadir;
	}

	public static Problem setProblem(String name, int obj) throws JMException,
			ClassNotFoundException {
		Problem problem = null;
		if (name.equals("DTLZ1") || name.equals("SDTLZ1")) {
			Object[] params = { "Real", obj + 4, obj };
			problem = (new ProblemFactory()).getProblem(name, params);
		} else if (name.equals("NDTLZ7")) {
			Object[] params = { "Real", obj + 19, obj };
			problem = (new ProblemFactory()).getProblem(name, params);
		} else if (name.startsWith("DTLZ") || name.equals("SDTLZ2")) {
			Object[] params = { "Real", obj + 9, obj };
			problem = (new ProblemFactory()).getProblem(name, params);
		} else if (name.startsWith("WFG") || name.startsWith("NWFG")) {
			Object[] params = { "Real", obj - 1, 25 - obj, obj };
			problem = (new ProblemFactory()).getProblem(name, params);
		}
		else {
			System.out.println("Error: function type " + name + " invalid");
			System.exit(-1);
		}
		return problem;
	}

	
	public static void filterSolutions(SolutionSet pop, Solution ref) {
		int i = 0;
		while (i < pop.size()) {
			Solution sol = pop.get(i);
			int res = new DominanceComparator().compare(sol, ref);
			if (res != -1)
				pop.remove(i);
			else
				i++;
		}
	}

	public static void print(SolutionSet population, long time, String path)
			throws FileNotFoundException {
		File file = new File(path);
		PrintWriter out = new PrintWriter(new OutputStreamWriter(
				new FileOutputStream(file, false)));
		int objs = population.get(0).numberOfObjectives();

		for (int i = 0; i < population.size(); i++) {
			Solution sol = population.get(i);
			for (int j = 0; j < objs - 1; j++)
				out.print(sol.getObjective(j) + " ");
			out.println(sol.getObjective(objs - 1));
		}

		out.println("Time: " + time);

		out.close();

	}

	static int[] setDivs(int obj) {
		int divs[] = new int[2];

		if (obj == 2) {
			divs[0] = 99;
			divs[1] = 0;
		}  else if (obj == 5) {
			divs[0] = 6;
			divs[1] = 0;
		} else if (obj == 8) {
			divs[0] = 3;
			divs[1] = 3;
		} else if (obj == 10) {
			divs[0] = 3;
			divs[1] = 2;
		} else if (obj == 13) {
			divs[0] = 2;
			divs[1] = 2;
		} else {
			divs[0] = 90;
			divs[1] = 0;
		}
		return divs;
	}
	
}
