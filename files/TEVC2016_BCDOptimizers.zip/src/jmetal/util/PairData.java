package jmetal.util;

public class PairData implements Comparable<PairData> {
	private int dataId;
	private double dataVal;

	public PairData(int id, double val) {
		this.dataId = id;
		this.dataVal = val;
	}

	public int getID(){
		return dataId;
	}
	
	public double getValue(){
		return dataVal;
	}
	

	public int compareTo(PairData sObj) {

		if (dataVal < sObj.dataVal)
			return -1;
		else if (dataVal > sObj.dataVal)
			return 1;
		else
			return 0;
	}
}
	