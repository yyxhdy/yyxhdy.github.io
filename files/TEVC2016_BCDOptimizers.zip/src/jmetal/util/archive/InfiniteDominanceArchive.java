package jmetal.util.archive;

import java.util.Comparator;

import jmetal.core.Solution;
import jmetal.util.Distance;
import jmetal.util.comparators.CrowdingDistanceComparator;
import jmetal.util.comparators.DominanceComparator;
import jmetal.util.comparators.EqualSolutions;

public class InfiniteDominanceArchive extends Archive {
	
	
	private Comparator dominance_;
	
	private Comparator equals_;
	
	public InfiniteDominanceArchive() {
		super();

		dominance_ = new DominanceComparator();

		equals_ = new EqualSolutions();
	} 
	
	
	
	public boolean add(Solution solution) {

		int i = 0;
		while (i < solutionsList_.size()) {
			Solution aux = solutionsList_.get(i);

			int flag = dominance_.compare(solution, aux);
			if (flag == 1) { // The solution to add is dominated
				return false; // Discard the new solution
			} else if (flag == -1) { // A solution in the archive is dominated
				solutionsList_.remove(i); // Remove it from the population
			} else {
				if (equals_.compare(aux, solution) == 0) { // There is an equal
															// solution
					// in the population
					return false; // Discard the new solution
				} // if
				i++;
			}
		}
		solutionsList_.add(solution);
		return true;

	} // add
}
